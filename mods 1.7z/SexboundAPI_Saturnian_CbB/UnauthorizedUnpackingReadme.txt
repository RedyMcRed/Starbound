This mod files contains the compatibility for the race only.

You have unpacked this mod without my permission and its a bit disrespectful in my point-of-view.

								- Alastor, Sexbound Moderator & R.C.M.