function init()
   effect.addStatModifierGroup({{stat = "fireResistance", amount = 0.75}, {stat = "fireStatusImmunity", amount = 1}})

   script.setUpdateDelta(0)
end

function update(dt)

end

function uninit()
  
end
