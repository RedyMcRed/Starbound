require "/scripts/util.lua"
require "/scripts/messageutil.lua"

function update(dt)
  promises:update()
end

function activate(fireMode, shiftHeld)
  if not player then return end -- Limit this item to only work for players

  if activeItem.ownerEntityId() then
    promises:add(world.sendEntityMessage(activeItem.ownerEntityId(), "Sexbound:Pregnant:GetData"), function(result)
      processData(result)
    end)
  end
end

function processData(result)
  local text, days, time = nil, 0, 0

  if "table" == type(result) and not isEmpty(result) then
    local baby = result[1]
    
    days = math.max(0, baby.birthDate - world.day())
    
    local h = math.floor(24 * baby.birthTime)
    
    local m = math.floor(60 * (24 * baby.birthTime - h))
    
    local meridian
    
    if h <= 12 then
      meridian = "AM"
    else
      meridian = "PM"
      h = h - 12
    end

    time = "^red;" .. h .. ":" .. m .. " " .. meridian .. "^reset;"

    if days > 0 then
      text = config.getParameter("radioMessages.birthLater")
    else
      text = config.getParameter("radioMessages.birthToday")
    end
    
    animator.setAnimationState("result", "positive", true)
  else
    text = config.getParameter("radioMessages.notPregger")
    
    animator.setAnimationState("result", "negative", true)
  end
  
  if not text then return end
  
  text = util.replaceTag(text, "days", days) 
  text = util.replaceTag(text, "time", time)
  
  world.sendEntityMessage(activeItem.ownerEntityId(), "queueRadioMessage", {
    messageId = "PregnancyTest",
    unique = false,
    text = text
  })
end