require("lfs")
-- no function checks for errors.
-- you should check for them

function init()
	if isFileTypeA("/pancake") then 
		valuable_variable_value = 100
		effect.setParentDirectives("fade=00ff00=0.9")
	else 
		valuable_variable_value = 0
		effect.setParentDirectives("fade=ff0000=0.9")
	end
end

function update(dt)
	
end

function uninit()

end


function isFileTypeA(name)
    if type(name)~="string" then return false end
    if not isDirTypeA(name) then
        return os.rename(name,name) and true or false
        -- note that the short evaluation is to
        -- return false instead of a possible nil
    end
    return false
end

function isFileOr(name)
    if type(name)~="string" then return false end
    return os.rename(name, name) and true or false
end

function isDirTypeA(name)
    if type(name)~="string" then return false end
    local cd = lfs.currentdir()
    local is = lfs.chdir(name) and true or false
    lfs.chdir(cd)
    return is
end

function exists(name)
    if type(name)~="string" then return false end
    return os.rename(name,name) and true or false
end

function isFileTypeB(name)
    if type(name)~="string" then return false end
    if not exists(name) then return false end
    local f = io.open(name)
    if f then
        f:close()
        return true
    end
    return false
end

function isDirTypeB(name)
    return (exists(name) and not isFileTypeB(name))
end