require "/lewdScripts/wangSpawner.lua"

function init()
  animator.setParticleEmitterOffsetRegion("drips", mcontroller.boundBox())
  animator.setParticleEmitterActive("drips", true)
end

function update(dt)
	if entity.entityType() == "npc" or entity.entityType() == "player" then
		gimmeWang(entityID)
	end 
end

function uninit()

end
