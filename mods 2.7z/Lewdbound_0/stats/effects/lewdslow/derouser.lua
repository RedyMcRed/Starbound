function init()
  animator.setParticleEmitterOffsetRegion("drips", mcontroller.boundBox())
  animator.setParticleEmitterActive("drips", true)
end

function update(dt)
	if entity.entityType() == "npc" then
		if status.resource("arousal") == nil then return 
		else status.setResource("arousal", 0) 
		end
	end 
	if entity.entityType() == "monster" then
		if status.isResource("arousal") ~= false then
		  status.setResource("arousal", 0) 
		end
	end 
end

function uninit()

end
