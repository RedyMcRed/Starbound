function init()
   effect.addStatModifierGroup({{stat = "maxHealth", amount = config.getParameter("healthAmount", 0)}})
   effect.addStatModifierGroup({{stat = "maxEnergy", amount = config.getParameter("energyAmount", 0)}})
   effect.addStatModifierGroup({{stat = "electricResistance", amount = 0.95}, {stat = "electricStatusImmunity", amount = 1}})
   effect.addStatModifierGroup({{stat = "fireResistance", amount = 0.95}, {stat = "fireStatusImmunity", amount = 1}})
   effect.addStatModifierGroup({{stat = "iceResistance", amount = 0.95}, {stat = "iceStatusImmunity", amount = 1}})
  self.movementParameters = config.getParameter("movementParameters", {})
  local bounds = mcontroller.boundBox()
  effect.addStatModifierGroup({
    {stat = "jumpModifier", amount = 1.5}
  })
  
  --Power
  self.powerModifier = config.getParameter("powerModifier", 0)
  effect.addStatModifierGroup({{stat = "powerMultiplier", effectiveMultiplier = self.powerModifier}})

  local enableParticles = config.getParameter("particles", true)
  animator.setParticleEmitterOffsetRegion("embers", mcontroller.boundBox())
  animator.setParticleEmitterActive("embers", enableParticles)
  
  script.setUpdateDelta(3)
end

function update(dt)
  mcontroller.controlModifiers({
      airJumpModifier = 5.50
    })
  mcontroller.controlModifiers({
      speedModifier = 5.50
    })
  animator.setFlipped(mcontroller.facingDirection() == -1)
  mcontroller.controlParameters(self.movementParameters)
end

function uninit()
  
end
