function init()
   effect.addStatModifierGroup({{stat = "maxHealth", amount = config.getParameter("healthAmount", 0)}})
   effect.addStatModifierGroup({{stat = "maxEnergy", amount = config.getParameter("energyAmount", 0)}})
   effect.addStatModifierGroup({{stat = "electricResistance", amount = 1}, {stat = "electricStatusImmunity", amount = 1}})
   effect.addStatModifierGroup({{stat = "fireResistance", amount = 1}, {stat = "fireStatusImmunity", amount = 1}})
   effect.addStatModifierGroup({{stat = "iceResistance", amount = 1}, {stat = "iceStatusImmunity", amount = 1}})
  self.movementParameters = config.getParameter("movementParameters", {})
  local bounds = mcontroller.boundBox()
  effect.addStatModifierGroup({
    {stat = "jumpModifier", amount = 5.5}
  })
  
  --Power
  self.powerModifier = config.getParameter("powerModifier", 0)
  effect.addStatModifierGroup({{stat = "powerMultiplier", effectiveMultiplier = self.powerModifier}})

  local enableParticles = config.getParameter("particles", true)
  animator.setParticleEmitterOffsetRegion("embers", mcontroller.boundBox())
  animator.setParticleEmitterActive("embers", enableParticles)
  
    effect.addStatModifierGroup({
    {stat = "lavaImmunity", amount = 1},
    {stat = "poisonStatusImmunity", amount = 1},
    {stat = "tarImmunity", amount = 1},
    {stat = "waterImmunity", amount = 1},
  })
  
  script.setUpdateDelta(3)
end

function update(dt)
  mcontroller.controlModifiers({
      airJumpModifier = 10.00
    })
  mcontroller.controlModifiers({
      speedModifier = 10.00
    })
  animator.setFlipped(mcontroller.facingDirection() == -1)
  mcontroller.controlParameters(self.movementParameters)
end

function uninit()
  
end
